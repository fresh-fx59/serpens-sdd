---
description: Структурированное предварительное ревью diff до ревью человеком
serpens-version: 2026-10-01.1
---
`<change-id>` — проверяемое изменение OpenSpec; `<openspec>` — вызов CLI OpenSpec, подставленный
при установке.
Проверь diff {{args}} (branch/change request/change — слово для «change request» в этом окружении
— `forge-word` из `<serpens-sdd> delivery --print-contract`). Следуй spns-code-review. Дай findings по важности
(blocker / serious / minor), каждый с file:line и конкретным исправлением.
0. СОСТОЯНИЕ: установи `REPO_ROOT="$(git rev-parse --show-toplevel)"`, выполни
   `<serpens-sdd> state inspect`. Для локальной ветки истории
   также выполни `<serpens-sdd> state assert-change <TICKET> --allow-dirty`.
1. ПОКРЫТИЕ: сначала `<openspec> validate <change-id> --type change --strict --json` и
   `<openspec> status --change <change-id> --json` (с `--store <store-id>`, если изменение
   в хранилище). Ошибка валидации или незакрытая задача — blocker; WARNING — минимум serious.
   Они доказывают полноту артефактов и задач, но не запуск теста. Если это не
   OpenSpec-изменение, отметь это.
2. СООТВЕТСТВИЕ СПЕКЕ: реализовано ровно требуемое, без пропусков и лишнего.
3. ПРИЁМКА: сценарии каждого ADDED/MODIFIED требования называют, что тестировщик отправляет и что
   наблюдает снаружи. Если построенная система противоречит сценарию, в диффе должна быть правка
   спеки — молча исправленное ожидание в комментарии трекера это минимум serious.
4. ЧЕСТНОСТЬ ТЕСТОВ: тест проверяет поведение сценария и упал бы при поломке функции.
5. КОРРЕКТНОСТЬ: ошибки, границы сценариев, error handling, конкуренция общего состояния.
6. DISPOSER: `<serpens-sdd> verify-docs`; любая ошибка — blocker.
Не approve и не merge — `review-may-merge` всегда `no`. Решение принимает человек. Если diff
чистый, скажи одной строкой.
